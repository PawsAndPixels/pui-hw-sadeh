
const queryString = window.location.search;
//URLSearchParams
const params = new URLSearchParams(queryString);
const rollType = params.get('roll');


let searchparams = new URLSearchParams(window.location.search);
let title = searchparams.get("title");
let currentid = searchparams.get("id");

// Update the product detail header text
console.log(rollType);

let productDetailHeader = document.querySelector(".roll-type");
productDetailHeader.innerText = rollType + " cinnamon roll";

let productDetailImage = document.querySelector(".product-detail-image");
productDetailImage.src = "../assets/products/" + rolls[rollType].imageFile; 


console.log(rolls.Original.basePrice);
console.log(rolls.Original.imageFile);

function addToCartClicked()
{
    let rollGlazing = glazingSelect.options[glazingSelect.selectedIndex].text;
    let packSize = sizeSelect.options[sizeSelect.selectedIndex].text;
    const rollInstance = new Roll(rollType, rollGlazing, packSize, rolls[rollType].basePrice);
    cartSet.add(rollInstance);
    let setString = JSON.stringify(cartSet);
    localStorage.setItem("cartSet", setString);
    console.log(setString);
    console.log(cartSet);
}
