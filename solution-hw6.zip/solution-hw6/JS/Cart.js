class Cart{
    constructor(rollType, rollGlazing, packSize, basePrice, imageURL)
    {
        this.type = rollType;
        this.glazing = rollGlazing;
        this.size = packSize;
        this.basePrice = basePrice;
        this.imageURL = imageURL;

        this.element = null; //corresponds to the .cart element in DOM
    }
}
/*
/////////////////////////////////////////
calculatePrice(newRoll) //don't think this is correct
{
    let glazingPrice = glazingPrices[this.glazing];
    //rolls[rollType].basePrice;
    return(this.basePrice + glazingPrice) * this.size;
}
*/

function addNewRoll(imageURL, title, body){
  const cart = new Cart(imageURL, title, body);
  cartSet.add(cart);
}

function createElement(cart)
{
    console.log("Creating an Element!")
    const template = document.querySelector('#cart-template');
    console.log(template);
    const clone = template.content.cloneNode(true);
    cart.element = clone.querySelector('.cart');
    console.log(cart.element);
    const cartListItem = document.querySelector('#cart-list');
    cartListElement.append(cart.element);


    updateElement(cart);
    // cartItem.classList.add("cart-item")
}

function updateElement(cart)
{
    //type...basePrice.image STEP 27...
    const cartImageElement = cart;
}

/*
console.log(cart);

function appendToShoppingCart(roll)
{
    const cartItem = document.createElement("div");
    cartItem.classList.add("cart-item")
}

const rollImage = document.createElement("img");
rollImage.src = "../assets/products/${rolls[roll.type].imageFile}"
rollImage.alt = this.type;

const rollDetails = document.createElement('div');
rollDetails.classList.add('cart-item-details');

  // Create and populate elements for name, glazing, pack size, and price
const nameElement = document.createElement('p');
nameElement.textContent = this.type;

const glazingElement = document.createElement('p');
glazingElement.textContent = this.glazing;

const packSizeElement = document.createElement('p');
packSizeElement.textContent = this.size;

const priceElement = document.createElement('p');
const rollPrice = roll.calculatePrice(); // Calculate the item price
priceElement.textContent = `$${rollPrice.toFixed(2)}`;
*/
  // Create a remove button
  const removeButton = document.createElement('button');
  removeButton.textContent = 'Remove';
  removeButton.classList.add('remove-button');

/*
  removeButton.addEventListener('click', () => {
    // Remove the item from the cart array
    const index = cart.indexOf(roll);
    if (index !== -1) {
      cart.splice(index, 1);
    }

    // Remove the cart item from the DOM
    cartItem.parentNode.removeChild(cartItem);

    // Update the total price
    updateTotalPrice();
  });

  // Append elements to the cart item container
  rollDetails.appendChild(nameElement);
  rollDetails.appendChild(glazingElement);
  rollDetails.appendChild(packSizeElement);
  rollDetails.appendChild(priceElement);
  cartItem.appendChild(rollImage);
  cartItem.appendChild(rollDetails);
  cartItem.appendChild(removeButton);

  // Append the cart item to the shopping cart container
  const shoppingCart = document.querySelector('.shopping-cart');
  shoppingCart.appendChild(cartItem);

  // Update the total price
  updateTotalPrice();

// Function to update the total price
function updateTotalPrice() {
  const totalPriceElement = document.querySelector('.total-price');

  // Calculate the total price based on the items in the cart
  const totalPrice = cart.reduce((total, roll) => {
    return total + roll.calculatePrice();
  }, 0);

  totalPriceElement.textContent = `$${totalPrice.toFixed(2)}`;
}

cart.forEach((roll) => {
  appendToShoppingCart(roll);
});

*/