// removes a cart item from the cartSet
function removeCartItemFromSet(cartItemId) {
    for (const cartItem of cartSet) {
        if (cartItem.id === cartItemId) {
            cartSet.delete(cartItem);
            break; // Exit the loop once the item is found and removed.
        }
    }
    updateTotalPrice();
    updateLocalStorage();
}

document.addEventListener("DOMContentLoaded", function() {
    const originalRoll = createInitRoll(
        "Original",
        "Sugar Milk",
        1,
        2.49
        );

    const walnutRoll = createInitRoll(
        "Walnut",
        "Vanilla Milk",
        12,
        3.49
        );

    const raisinRoll = createInitRoll(
        "Raisin",
        "Sugar Milk",
        3,
        2.99
        );

    const appleRoll = createInitRoll(
        "Apple",
        "Original",
        3,
        3.49
        );

    // When the page loads, attempt to retrieve the cart from local storage.
    let newSet = JSON.parse(localStorage.getItem('cart'));
    if(newSet){
        cartSet = newSet;
    }
    //console.log("loaded initial set from storage");

    // Ensure the DOM is fully loaded before attaching event listeners.
    const removeButtons = document.querySelectorAll('.remove-product');
    
    removeButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Find the corresponding cart item and remove it from cartSet.
            const cartItem = button.closest('.cart-item-w-remove-button');
            if (cartItem) {
                const cartItemId = cartItem.dataset.itemId; // You can set this in your HTML.
                removeCartItemFromSet(cartItemId);
            }
        });
    });

    // Update total price and create cart elements
    updateTotalPrice();
    for (const newCart of cartSet) {
        createCartElement(newCart);
    }
});


function createElement(newCartDisplay) {
    const template = document.querySelector('#cart-template');
    const clone = template.content.cloneNode(true);

    newCartDisplay.element = clone.querySelector('.cart-roll-item');

    const btnDelete = newCartDisplay.element.querySelector('.remove-product');
    btnDelete.addEventListener('click', () => {
        deleteCart(newCartDisplay);
    });

    const newCartListElement = document.querySelector('.rollContainer');
    newCartListElement.prepend(newCartDisplay.element);

    updateCartElement(newCartDisplay);
}


function updateCartElement(newCart) {
    const { type, glazing, size, basePrice } = newCart;
    const newCartImage = newCart.element.querySelector('.cart-image');
    const newCartRollType = newCart.element.querySelector('.roll-type');
    const newCartRollGlazing = newCart.element.querySelector('.glazing-type');
    const newCartPackSize = newCart.element.querySelector('.pack-size');
    const newCartBasePrice = newCart.element.querySelector('.base-price');

    newCartImage.src = `../assets/products/${rolls[type].imageFile}`;
    newCartRollType.innerText = type;
    newCartRollGlazing.innerText = glazing;
    newCartPackSize.innerText = size;
    newCartBasePrice.innerText = `$${basePrice.toFixed(2)}`;
}

function deleteCart(newCart) {
    newCart.element.remove();
    cartSet.delete(newCart);
    updateTotalPrice();
}

function updateTotalPrice() {
    let totalPrice = 0;
    for (const newCart of cartSet) {
        totalPrice += (newCart.basePrice + glazingPrices[newCart.glazing]) * packSize[newCart.size];
    }
    const totalElement = document.querySelector('.cart-total');
    totalElement.innerText = `Total: $${totalPrice.toFixed(2)}`;
}

function createInitRoll(rollType, rollGlazing, packSize, basePrice) {
    const newCart = new Roll(rollType, rollGlazing, packSize, basePrice);
    cartSet.add(newCart);
    let setString = JSON.stringify(cartSet);
    localStorage.setItem("cartSet", setString);
    console.log("saving to local: " + setString);
    return newCart;
}

// This function adds a new item to the cart when the user makes a selection
function addToCartClicked() {
    // Replace this with the code to obtain productInfo based on user selection.
    const productInfo = {
        rollType: "Original",
        glazing: "Keep original",
        packSize: "1",
        basePrice: 2.49
    };

    // Create a new Roll instance with the selected product information and add it to the cart.
    const newCartItem = addNewCart(productInfo.rollType, productInfo.glazing, productInfo.packSize, productInfo.basePrice);

    // Convert the updated cart to JSON and save it in local storage.
    const cartArray = Array.from(cartSet);
    const cartJSON = JSON.stringify(cartArray);
    localStorage.setItem('cart', cartJSON);

    // Print the current contents of the cart in local storage.
    console.log("Current Contents of the Cart in Local Storage:");
    console.log(cartArray);
}
