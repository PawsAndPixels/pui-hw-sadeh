// We use this class to represent our shopping cart. Each cart object contains
// data for a single item, and a reference to a DOM element
class Cart {

  // When we create a new Cart object, the "constructor"
  // function is run. In the constructor, "this" refers to the
  // newly created Cart object.
  /*
  constructor(imageURL, title, body) {
    this.cartImageURL = imageURL;
    this.cartTitle = title;
    this.cartBody = body;

    this.element = null;
  }
  */

  constructor(rollType, rollGlazing, packSize, basePrice)
    {
        this.type = rollType;
        this.glazing = rollGlazing;
        this.size = packSize;
        this.basePrice = basePrice;

        this.element = null; //corresponds to the .cart element in DOM
    }
}

// Create an empty Set, which will hold all of our cart objects. A Set is
// similar to an Array, but in a Set, an item can only be added once (there
// are no duplicates). Sets also allow for easy removal of items, using the
// Set.delete(item) function.
const cartSet = new Set();

// This function creates a new Cart object, and adds it to cartSet.
function addNewRoll(rollType, rollGlazing, packSize, basePrice) {
  // Create a new cart object. The Cart constructor takes three
  // arguments: the image URL, title text,  and body text.
  const cart = new Cart(rollType, rollGlazing, packSize, basePrice);

  // Add the cart object to our cart Set, which keeps track of all
  // the carts in our application.
  cartSet.add(cart);
  return cart;
}

let glazingPrices = {
  "original": 0.00, //2.49,
  "sugar": 0.00, //2.99,
  "vanilla": 0.50, //3.49,
  "double chocolate": 1.50 //3.99
};

let packSize = {
  "1": 1,
  "3": 3,
  "6": 6,
  "12": 12
};


function createElement(cart) {
  // make a clone of the card template
  const template = document.querySelector('#cart-template');
  const clone = template.content.cloneNode(true);
  
  // connect this clone to our cart.element
  // from this point we only need to refer to cart.element
  cart.element = clone.querySelector('.cart');
  //let element = clone.querySelector('.cart');

  const btnDelete = cart.element.querySelector('.remove-product');
  console.log(btnDelete);
  btnDelete.addEventListener('click', () => {
  deleteCart(cart);
  });
  
  // add the cart clone to the DOM
  // find the cart parent (#cart-list) and add our cart as its child
  const cartListElement = document.querySelector('#cart-list');
  cartListElement.prepend(cart.element);
  
  // populate the cart clone with the actual cart content
  updateElement(cart);
}

function updateElement(cart) {
  // get the HTML elements that need updating
  const cartImage = cart.element.querySelector('.cart-image');
  const cartRollType = cart.element.querySelector('.roll-type');
  const cartRollGlazing = cart.element.querySelector('.glazing-type');
  const cartPackSize = cart.element.querySelector('.pack-size');
  const cartBasePrice = cart.element.querySelector('.base-price');

  
  // copy our cart content over to the corresponding HTML elements
  cartImage.src = cart.cartImageURL;
  cartRollType.innerText = cart.type;
  cartRollGlazing.innerText = cart.glazing;
  cartPackSize.innerText = cart.size;  
}

function deleteCart(cart) {
  // remove the cart DOM object from the UI
  cart.element.remove();
  // remove the actual Cart object from our set of notecards
  cartSet.delete(cart);
}

function addNewRoll(rollType, rollGlazing, packSize, basePrice){
  const cart = new Cart(rollType, rollGlazing, packSize, basePrice);
  cartSet.add(cart);
  return cart;
}

//create 4 Roll objects and add them to the cart
const cartOne = addNewRoll(
  "Original",
  "Sugar Milk",
  "1",
  2.49
  );

const cartTwo = addNewRoll(
  "Walnut",
  "Vanilla Milk",
  "12",
  3.49
  );

const cartThree = addNewRoll(
  "Raisin",
  "Sugar Milk",
  "3",
  2.99
  );

const cartFour = addNewRoll(
  "Apple",
  "Original",
  "3",
  3.49
  );

for (const cart of cartSet) {
  console.log(cart);
  createElement(cart);
}